describe('check if ngHint plugin works on good apps', function() {
  it('should not have ngHint problems on a good app', function() {
    browser.get("ngHint/index.html");
  });
});
