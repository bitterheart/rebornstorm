exports.config = {
  onPrepare: 'foo/bar.js',
  specs: [ 'fakespec[AB].js' ],
  rootElement: '.mycontainer'
};
