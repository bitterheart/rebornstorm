describe('onCleanUp function in the config', function() {
  it('should not be affected by tests', function() {
    expect(true).toBe(true);
  });
});
